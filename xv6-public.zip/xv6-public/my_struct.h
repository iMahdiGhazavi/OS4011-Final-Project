
struct proc_info {
  int pid;
  int memsize; // in bytes
};